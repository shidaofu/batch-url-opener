// 国际化函数
function i18n(messageName, substitutions = []) {
    return chrome.i18n.getMessage(messageName, substitutions);
}

// 初始化国际化
function initI18n() {
    // 设置页面标题
    document.title = i18n('pageTitle');
    
    // 设置所有带有 data-i18n 属性的元素
    document.querySelectorAll('[data-i18n]').forEach(element => {
        const messageName = element.getAttribute('data-i18n');
        if (messageName) {
            if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
                element.placeholder = i18n(messageName);
            } else {
                element.textContent = i18n(messageName);
            }
        }
    });
    
    // 设置带有 data-i18n-placeholder 属性的元素
    document.querySelectorAll('[data-i18n-placeholder]').forEach(element => {
        const messageName = element.getAttribute('data-i18n-placeholder');
        if (messageName) {
            element.placeholder = i18n(messageName);
        }
    });
}

// 获取 DOM 元素
const urlsTextarea = document.getElementById('urls');
const openBtn = document.getElementById('openBtn');
const clearBtn = document.getElementById('clearBtn');
const statusDiv = document.getElementById('status');

// 验证和规范化 URL
function normalizeUrl(url) {
    url = url.trim();
    if (!url) return null;
    
    // 如果 URL 不包含协议，添加 https://
    if (!url.match(/^https?:\/\//i)) {
        url = 'https://' + url;
    }
    
    try {
        // 验证 URL 格式
        new URL(url);
        return url;
    } catch (e) {
        // 如果 URL 格式不正确，尝试修复
        try {
            new URL('https://' + url);
            return 'https://' + url;
        } catch (e2) {
            return null;
        }
    }
}

// 解析文本区域中的 URL
function parseUrls(text) {
    const lines = text.split('\n');
    const urls = [];
    
    for (let line of lines) {
        const normalized = normalizeUrl(line);
        if (normalized) {
            urls.push(normalized);
        }
    }
    
    return urls;
}

// 批量打开 URL
async function openUrls(urls) {
    if (urls.length === 0) {
        showStatus(i18n('statusEmptyUrl'), 'error');
        return;
    }
    
    showStatus(i18n('statusOpening', [urls.length.toString()]), 'info');
    
    let successCount = 0;
    let failCount = 0;
    
    for (let i = 0; i < urls.length; i++) {
        const url = urls[i];
        try {
            // 使用 chrome.tabs API 打开新标签页
            await chrome.tabs.create({
                url: url,
                active: i === 0  // 只有第一个标签页设为活动状态
            });
            successCount++;
        } catch (error) {
            console.error(i18n('errorOpenFailed', [url]), error);
            failCount++;
        }
        
        // 显示进度
        if (i < urls.length - 1) {
            showStatus(i18n('statusProgress', [(i + 1).toString(), urls.length.toString()]), 'info');
        }
    }
    
    // 显示最终结果
    if (failCount === 0) {
        showStatus(i18n('statusSuccess', [successCount.toString()]), 'success');
    } else {
        showStatus(i18n('statusPartial', [successCount.toString(), failCount.toString()]), 'warning');
    }
    
    // 3 秒后清空状态
    setTimeout(() => {
        statusDiv.textContent = '';
        statusDiv.className = 'status';
    }, 3000);
}

// 显示状态信息
function showStatus(message, type = 'info') {
    statusDiv.textContent = message;
    statusDiv.className = `status ${type}`;
}

// 打开按钮点击事件
openBtn.addEventListener('click', async () => {
    const text = urlsTextarea.value;
    const urls = parseUrls(text);
    await openUrls(urls);
});

// 清空按钮点击事件
clearBtn.addEventListener('click', () => {
    urlsTextarea.value = '';
    statusDiv.textContent = '';
    statusDiv.className = 'status';
    urlsTextarea.focus();
});

// 支持 Ctrl+Enter 快捷键打开
urlsTextarea.addEventListener('keydown', (e) => {
    if (e.ctrlKey && e.key === 'Enter') {
        openBtn.click();
    }
});

// 页面加载时初始化
window.addEventListener('load', () => {
    initI18n();
    urlsTextarea.focus();
});

